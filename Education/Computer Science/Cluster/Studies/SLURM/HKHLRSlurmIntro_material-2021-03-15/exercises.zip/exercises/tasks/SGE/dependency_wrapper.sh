#!/bin/bash

jid1=$(qsub dependency_1.sge  | head -n 1 | awk '{FS=" ";print $3}')
echo "Submitted job ID $jid1"
jid2=$(qsub -hold_jid $jid1 dependency_2.sge  | head -n 1 | awk '{FS=" ";print $3}')
echo "Submitted job ID $jid2"
