#!/bin/bash

echo $(($1 * $1))
