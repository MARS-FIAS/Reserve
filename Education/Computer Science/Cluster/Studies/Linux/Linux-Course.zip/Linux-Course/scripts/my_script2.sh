#!/bin/bash

a=10

if [ $a -gt 0 ]; then
  echo "a is greater than zero"
else
  echo "a is NOT greater than zero"
fi
