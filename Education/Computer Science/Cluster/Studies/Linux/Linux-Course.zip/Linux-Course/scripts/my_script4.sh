#!/bin/bash

for i in 1 2 3 10 11 hundred; do
  echo "Print i = $i"
done
