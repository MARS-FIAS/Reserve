#!/bin/bash

#This line is a comment.

echo 'Hello world!'
