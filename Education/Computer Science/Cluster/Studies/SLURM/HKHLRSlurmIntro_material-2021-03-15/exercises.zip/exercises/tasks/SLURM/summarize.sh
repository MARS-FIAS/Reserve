#!/bin/bash

sum=0

for outfile in task2_*.out; do
    add=`cat $outfile`
    sum=$(($sum + $add))
done
echo $sum
